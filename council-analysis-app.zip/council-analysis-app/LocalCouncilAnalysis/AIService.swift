import Foundation

/// Placeholder service for generating summaries.
///
/// In this proof‑of‑concept, the summarisation is stubbed out and
/// simply returns the first 1000 characters of the raw JSON response
/// from the postcode API.  In a finished application this class would
/// encapsulate the logic for calling an on‑device Core ML model or a
/// server‑based generative AI service fine‑tuned on council data.
final class AIService {
    static let shared = AIService()

    private init() {}

    /// Produces a brief summary of the given JSON string.
    /// - Parameter json: Raw JSON from the postcode API
    /// - Returns: A human‑readable summary (currently truncated JSON)
    func summarize(json: String) -> String {
        guard !json.isEmpty else { return "No data returned." }
        let truncated = json.prefix(1000)
        return String(truncated)
    }
}