import SwiftUI

/// The main view for entering a postcode and viewing the analysis.
///
/// Users can type a UK postcode and tap the button to fetch data about
/// their local authority.  The view performs a simple GET request to
/// MapIt’s postcode API, then hands the raw JSON to a summarisation
/// service.  In the finished application this would trigger a scraper
/// and call an on‑device generative AI model that summarises meeting
/// minutes, spending data and other council information.
struct ContentView: View {
    @State private var postcode: String = ""
    @State private var results: String = ""
    @State private var isLoading: Bool = false

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Enter your postcode to see council activity")
                    .font(.headline)
                    .padding(.horizontal)

                TextField("E.g. SW1A 1AA", text: $postcode)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .autocapitalization(.allCharacters)
                    .keyboardType(.asciiCapable)
                    .padding(.horizontal)

                Button(action: fetchCouncilData) {
                    HStack {
                        Spacer()
                        if isLoading {
                            ProgressView()
                        } else {
                            Text("Find council")
                                .fontWeight(.semibold)
                        }
                        Spacer()
                    }
                }
                .disabled(postcode.trimmingCharacters(in: .whitespaces).isEmpty)
                .padding()

                ScrollView {
                    Text(results.isEmpty ? "Results will appear here." : results)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(8)
                .padding(.horizontal)

                Spacer()
            }
            .navigationTitle("Local Council Analysis")
        }
    }

    /// Fetches council data for the given postcode using MapIt and processes it.
    private func fetchCouncilData() {
        let trimmed = postcode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 5 else { return }

        // Replace spaces for the API call
        let cleaned = trimmed.replacingOccurrences(of: " ", with: "")
        guard let url = URL(string: "https://mapit.mysociety.org/postcode/\(cleaned)") else {
            return
        }

        isLoading = true
        results = ""
        let task = URLSession.shared.dataTask(with: url) { data, _, error in
            defer { DispatchQueue.main.async { self.isLoading = false } }
            guard error == nil, let data = data else {
                DispatchQueue.main.async {
                    self.results = "Failed to load data."
                }
                return
            }
            let json = String(data: data, encoding: .utf8) ?? ""
            // In a real app, the JSON would be parsed into a model and
            // additional scraping would be performed based on the council slug.
            let summary = AIService.shared.summarize(json: json)
            DispatchQueue.main.async {
                self.results = summary
            }
        }
        task.resume()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}