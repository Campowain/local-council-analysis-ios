# Local Council Analysis App (London Prototype)

This repository contains an early prototype of an iOS app that helps London residents understand what their borough councils have been doing.  Users enter a postcode, the app looks up the corresponding local authority, fetches recent activities (meetings, reports, decisions) from a backend service and generates a concise summary using a generative AI model.

## Structure

```
LocalCouncilAnalysisApp/
├── LocalCouncilAnalysisApp.swift        // Entry point for the app
├── Views/
│   └── ContentView.swift               // Main UI for postcode entry and results
├── Services/
│   ├── CouncilService.swift            // Networking: postcode lookup & activity fetch
│   └── AIService.swift                 // Placeholder AI summariser
└── Models/
    └── Activity.swift                  // Activity data model
```

## Development Plan

This code accompanies a requirements document outlining user stories and a development roadmap.  Future work includes:

* Building a proper backend for scraping council data.
* Integrating a fine‑tuned AI model for summarisation and Q&A.
* Adding topic filters, chat interface, notifications and offline caching.
* Writing unit and UI tests and setting up continuous integration.

## Running

This is not yet a complete Xcode project.  To try it out:

1. Create a new SwiftUI iOS project in Xcode (targeting iOS 14 or later).
2. Delete the default `App` and `ContentView` files.
3. Drag the files from `LocalCouncilAnalysisApp` into your project and ensure they are added to the app target.
4. Build and run.  The `CouncilService` makes live requests to the MapIt API and uses stubbed data for council activities.

**Note:** The AI summarisation is currently stubbed; you will see placeholder text.
