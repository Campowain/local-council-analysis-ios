import Foundation

/// Placeholder service for generating summaries.
///
/// In this proof‑of‑concept, the summarisation is stubbed out and
/// simply returns the first 1000 characters of the input string.  In a
/// finished application this class would encapsulate the logic for
/// calling an on‑device Core ML model or a server‑based generative AI
/// service fine‑tuned on council data.
final class AIService {
    static let shared = AIService()

    private init() {}

    /// Produces a brief summary of the given text.
    ///
    /// - Parameter text: Raw text or JSON from any data source.
    /// - Returns: A human‑readable summary (currently truncated input).
    func summarize(text: String) -> String {
        guard !text.isEmpty else { return "No data returned." }
        let truncated = text.prefix(1000)
        return String(truncated)
    }
}
