import SwiftUI

/// The main view for entering a postcode and viewing the analysis.
///
/// Users can type a UK postcode and tap the button to fetch data about
/// their local authority.  The view uses `CouncilService` to look up
/// the authority and retrieve recent council activity.  The returned
/// activity text is then passed through `AIService` for summarisation.
struct ContentView: View {
    @State private var postcode: String = ""
    @State private var summary: String = ""
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    private let councilService = CouncilService()

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Enter your postcode to see council activity")
                    .font(.headline)
                    .padding(.horizontal)

                TextField("E.g. SW1A 1AA", text: $postcode)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .textInputAutocapitalization(.characters)
                    .keyboardType(.asciiCapable)
                    .padding(.horizontal)

                Button(action: fetchCouncilData) {
                    HStack {
                        Spacer()
                        if isLoading {
                            ProgressView()
                        } else {
                            Text("Find council")
                                .fontWeight(.semibold)
                        }
                        Spacer()
                    }
                }
                .disabled(postcode.trimmingCharacters(in: .whitespaces).isEmpty || isLoading)
                .padding()

                ScrollView {
                    if let error = errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                    } else if !summary.isEmpty {
                        Text(summary)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                    } else {
                        Text("Results will appear here.")
                            .foregroundColor(.secondary)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(8)
                .padding(.horizontal)

                Spacer()
            }
            .navigationTitle("Local Council Analysis")
        }
    }

    /// Fetches council data for the given postcode using `CouncilService` and processes it.
    private func fetchCouncilData() {
        let trimmed = postcode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 5 else {
            errorMessage = "Please enter a valid postcode."
            return
        }
        isLoading = true
        summary = ""
        errorMessage = nil
        Task {
            do {
                // Look up the council
                let (name, code) = try await councilService.fetchCouncil(for: trimmed)
                // Fetch recent activities
                let activities = try await councilService.fetchCouncilActivities(for: code)
                // Summarise using the AI service
                let summarised = AIService.shared.summarize(text: activities)
                await MainActor.run {
                    self.summary = "Local authority: \(name)\n\n\(summarised)"
                }
            } catch let serviceError as CouncilService.Error {
                await MainActor.run {
                    self.errorMessage = serviceError.localizedDescription
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                }
            }
            await MainActor.run {
                self.isLoading = false
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
