import Foundation

/// A simple model representing a council activity item such as a meeting, report or decision.
struct Activity: Identifiable, Decodable {
    let id = UUID()
    let date: Date
    let title: String
    let category: String
    let description: String
    let sourceURL: URL?
}
