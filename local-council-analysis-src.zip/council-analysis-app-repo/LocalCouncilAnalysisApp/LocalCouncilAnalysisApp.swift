import SwiftUI

/// Entry point for the LocalCouncilAnalysis iOS app.
///
/// This proof‑of‑concept demonstrates a minimal SwiftUI app that accepts a
/// postcode, calls a postcode lookup service and passes the response to a
/// placeholder summarisation service.  The finished product would integrate
/// an on‑device large language model via Core ML and summarise the scraped
/// council data for the user.
@main
struct LocalCouncilAnalysisApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}