import Foundation

/// A service responsible for looking up a UK local authority from a postcode and
/// retrieving recent council activity.  This object encapsulates all network
/// calls so the view layer can remain declarative and free of networking logic.
///
/// The implementation uses the MapIt API to convert a postcode into a local
/// authority code.  Once the authority is identified, a second call is made
/// to an (imaginary) endpoint that aggregates council meeting minutes, budget
/// reports and news articles.  In a production build this endpoint would
/// connect to a scraper or internal data source; here it simply returns a
/// placeholder string.  All public functions are marked `async` so they can
/// be awaited from SwiftUI task contexts.
final class CouncilService {
    /// Errors thrown by `CouncilService` methods.
    enum Error: Swift.Error, LocalizedError {
        case invalidPostcode
        case decodingFailed
        case noCouncil
        case networkFailed

        var errorDescription: String? {
            switch self {
            case .invalidPostcode:
                return "Please enter a valid UK postcode."
            case .decodingFailed:
                return "Unable to decode the response from the server."
            case .noCouncil:
                return "No local authority was found for that postcode."
            case .networkFailed:
                return "A network error occurred while contacting the server."
            }
        }
    }

    /// Represents a simplified MapIt response containing the local authority name
    /// and code.  The full MapIt response contains many more fields, but for
    /// brevity we only parse what we need here.
    private struct MapItResponse: Decodable {
        struct Council: Decodable {
            let name: String
            let type: String
            let codes: Codes

            struct Codes: Decodable {
                let ons: String?
                let gss: String?
            }
        }

        /// MapIt returns a dictionary keyed by area identifier; each entry
        /// describes a different administrative area.  We choose the first
        /// district/unitary or county area as the council.
        let areas: [String: Council]
    }

    /// Look up the local authority for a given postcode using the MapIt API.
    ///
    /// - Parameter postcode: A UK postcode, with or without spaces.
    /// - Returns: The name and code of the local authority.
    func fetchCouncil(for postcode: String) async throws -> (name: String, code: String) {
        let trimmed = postcode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 5 else { throw Error.invalidPostcode }
        let cleaned = trimmed.replacingOccurrences(of: " ", with: "")
        guard let url = URL(string: "https://mapit.mysociety.org/postcode/\(cleaned)") else {
            throw Error.invalidPostcode
        }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decoder = JSONDecoder()
            let response = try decoder.decode(MapItResponse.self, from: data)
            // Choose the first council type entry by preferring district/unitary or county
            if let match = response.areas.values.first(where: { $0.type.lowercased().contains("district") || $0.type.lowercased().contains("unitary") || $0.type.lowercased().contains("county") }) {
                let code = match.codes.gss ?? match.codes.ons ?? ""
                return (match.name, code)
            } else if let any = response.areas.values.first {
                let code = any.codes.gss ?? any.codes.ons ?? ""
                return (any.name, code)
            }
            throw Error.noCouncil
        } catch let decodingError as Swift.DecodingError {
            print("Decoding error: \(decodingError)")
            throw Error.decodingFailed
        } catch {
            print("Network error: \(error)")
            throw Error.networkFailed
        }
    }

    /// Fetch recent council activity for the given authority code.
    ///
    /// In this proof‑of‑concept, no real scraping is performed.  The method
    /// simulates a network call with a short delay and returns a
    /// hard‑coded summary.  In a production system this would likely call
    /// your own backend service which aggregates and summarises council data.
    ///
    /// - Parameter code: The local authority code obtained from `fetchCouncil(for:)`.
    /// - Returns: A string describing recent council activity.
    func fetchCouncilActivities(for code: String) async throws -> String {
        // Simulate a network request by sleeping for a moment.  This helps
        // visualise the loading indicator in the UI.
        try await Task.sleep(nanoseconds: 1_000_000_000) // 1 second delay
        // Here you would perform a real network request to your backend or
        // directly scrape public data sources.  We'll return a placeholder.
        return "In the last 3 months the council has held several planning committee meetings, approved new housing developments, and published the annual budget. (Authority code: \(code))"
    }
}
